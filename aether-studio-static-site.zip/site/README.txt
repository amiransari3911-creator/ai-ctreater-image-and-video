Aether Studio — static HTML build
---------------------------------
Open index.html in any browser, or upload this whole folder to any static host
(Netlify, GitHub Pages, S3, IIS, Apache...).

Notes:
- index.html = home, auth.html = sign in page.
- AI image/video generation, sign-in and credits need the live backend and will
  not work from this static copy; it renders the full UI and gallery.
